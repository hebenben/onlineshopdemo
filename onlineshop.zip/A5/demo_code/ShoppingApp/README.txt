

This assignemt is written by ZeyeGu, 101036562, zeyegu@cmail.carleton.ca,in 2018/12/06.
 
Zeye_Gu //instance name	
192.168.50.229//fixed IP address
134.117.216.176 //floating IP address
The node verson is 8.11.4 and npm verson is 5.6.0.


First get mongod running. That is, start up the mongodb database listening
on its default port of 27017.
You need to clean the database if you want to test locally.
By using the following commends
use myShoppingApp3

db.departments.remove({})
db.categories.remove({})
db.products.remove({})
db.variants.remove({})

Next run the populate-for-startup.js
file inside the seed directory to populate the mongodb database.
You can run the file with below command (after locating in the terminal)
node populate-for-startup.js

** Important
Before starting application please make sure your mongo database runs.
To test the code from local , 
type the command: 
npm start
then you can access from localhost at
http://localhost:3000

Test the code on OpenStack
visit http://134.117.216.176:3000/


Login to the app using the dummy user for project:
username : admin@admin.com
password : admin
username : zeyegu@gmail.com
password : zeyegu


